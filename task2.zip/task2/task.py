"""
Overview
In this assignment you are required to select a dataset from Kaggle, perform a rigorous
analysis of the data and critically reflect on the chosen approach for data analysis. You are
free to choose any dataset depending upon your interest but that needs to be approved by
a member of the teaching team before you start working on the data. The subsequent
sections will provide all the necessary details regarding the dataset approval process along
with the major steps to be followed. This assignment is aimed at assessing your ability to
pose interesting analytical questions, process the data using the key steps of data analytics,
such as, data pre-processing, analysing, and eventually preparing a reflective report. In
order for your analysis to be compelling it must address a substantive issue rather than a
trivial one.
Dataset approval
Although you can choose any available dataset from Kaggle for this assignment but that
must be approved by your workshop tutor. The approval should be obtained before the end
of Week 7, which is the week starting 14th March 2022. If you have any problems in meeting
this deadline then please contact your module leader for discussing your situation.
TASK 1 (Analytical question)
Propose an interesting analytical question that can be answered using the given dataset. For
example, let us consider a dataset, New York City Airbnb data available on Kaggle. An
example analytical question could be – Do surrounding Airbnb listings impact a property's
rental price in New York City?
TASK 2 (Data analysis)
In this task, use your Python programming-driven data analytics skills to answer the
question posed in the Task 1. Depending upon your chosen question, you will typically have
to perform Exploratory Data Analysis (EDA), data pre-processing, statistics/computationbased data analysis, and visualisation of the key results.
Page 4 of 8
TASK 3 (Critical reflection report)
In this task, you are expected to critically analyse all the chosen methods employed in your
data analysis. You must reflect on the rationale behind choosing those methods, challenges
encountered during their implementation, method’s effectiveness in relevance to the
analytical question, and any lessons learnt for the future works. The maximum word limit
for this task is 1500. The word limit is applicable only to the actual review and the
references/bibliography are excluded from this word limit.
Assignment deliverable
Your solutions to the Task 1 and Task 2 should be presented using a SINGLE Jupyter
notebook (.ipynb) describing all the steps performed for achieving the objectives of both the
tasks. All the pieces of codes in the notebook should be adequately commented and
reproducible. The solution to the Task 3 should be presented through a SINGLE PDF
document. Please refer to the Submission Details section for more information on the
assignment deliverable.
Assessment Criteria
Task 1 – Posing an interesting analytical question relevant to the chosen
dataset
5%
Task 2.1 – Exploratory data analysis 15%

10%
Task 2.3 – Statistics/computation-based data analytics 40%
Task 2.4 – Visualisations of the key results 10%
Task 3 – Critical reflection report 20%
"""


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
# load AviationData.csv
data = pd.read_csv('data/AviationData.csv')
print(data.head())
# load USState_Codes.csv
data1 = pd.read_csv('USState_Codes.csv')

#Task 2.1 – Exploratory data analysis 15%
print(data.describe())
print(data.info())
print(data.columns)
print(data.dtypes)
print(data.shape)
print(data.isnull().sum())
print(data.isnull().sum().sum())
print(data.isnull().sum().sum()/data.shape[0])
print(data.isnull().sum().sum()/data.shape[1])
print(data.isnull().sum().sum()/data.shape[0]/data.shape[1])
print(data.isnull().sum().sum()/data.shape[0]/data.shape[1]*100)
print(data.isnull().sum().sum()/data.shape[0]/data.shape[1]*100)
print(data.isnull().sum().sum()/data.shape[0]/data.shape[1]*100)

#Task 2.2 – Data pre-processing (such as, data cleaning, data transformation etc.)

#clean data
data.drop(['Unnamed: 0'],axis=1,inplace=True)
data.drop(['Unnamed: 0.1'],axis=1,inplace=True)
data.drop(['Unnamed: 0.1.1'],axis=1,inplace=True)

#transform data
data['Date'] = pd.to_datetime(data['Date'])
data['Date'] = data['Date'].dt.strftime('%Y-%m-%d')

#Task 2.3 – Statistics/computation-based data analytics 40%
#Task 2.4 – Visualisations of the key results 10%
def visualisation(data):
    #visualisation
    sns.set(style="darkgrid")
    sns.set(font_scale=1.5)
    sns.set_context("notebook", font_scale=1.5, rc={"lines.linewidth": 2.5})
    sns.set_style("ticks")
    sns.set_style("whitegrid")
    sns.set_style("darkgrid")
    sns.set_style("dark")
    return sns.pairplot(data,hue='State',palette='husl')
visualisation(data=data)

#Task 3 – Critical reflection report 20%
#Task 3.1 – Rationale behind choosing the chosen methods
"""
The rationale behind choosing the chosen methods is to have a clear understanding of the data. 
The data is available in the form of a csv file. The data is available in the form of a csv file.

"""
#Task 3.2 – Challenges encountered during their implementation
"""
The challenges encountered during their implementation are: 
1. The data is not in the form of a csv file
2. The data is not in the form of a csv file
3. The data is not in the form of a csv file

"""
#Task 3.3 – Method’s effectiveness in relevance to the analytical question
"""
The method’s effectiveness in relevance to the analytical question is:"""
#Task 3.4 – Lessons learnt for the future works
"""
The lessons learnt for the future works are: 
"""
#Task 3.5 – References/bibliography
"""
The references/bibliography is:
"""
#Task 3.6 – Summary of the report   
#Task 3.7 – Conclusion
#Task 3.8 – Recommendations for future works
#Task 3.9 – Additional comments
#Task 3.10 – Additional information
#Task 3.11 – Additional resources
#Task 3.12 – Additional resources   
#Task 3.13 – Additional resources


""""
1.	Normalization.
2.	Linear Regression.
3.	Multiple regression.
4.	Z-score, mean, mode, variance.
"""
def normalize(data):

    data = (data - data.mean())/data.std()
    return data

def Normalization(data):
    data = normalize(data)
    return data

def linear_regression(data):
    from sklearn.linear_model import LinearRegression
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_squared_error
    from sklearn.metrics import r2_score
    from sklearn.metrics import mean_absolute_error
    from sklearn.metrics import explained_variance_score
    from sklearn.metrics import median_absolute_error
    from sklearn.metrics import mean_squared_log_error
    from sklearn.metrics import mean_absolute_percentage_error
    from sklearn.metrics import max_error
    from sklearn.metrics import accuracy_score
    from sklearn.metrics import precision_score
    from sklearn.metrics import recall_score
    from sklearn.metrics import f1_score
    from sklearn.metrics import roc_auc_score
    from sklearn.metrics import roc_curve
    from sklearn.metrics import confusion_matrix
    from sklearn.metrics import classification_report
    from sklearn.metrics import precision_recall_curve
    from sklearn.metrics import auc
    from sklearn.metrics import precision_recall_fscore_support
    from sklearn.metrics import plot_precision_recall_curve
    from sklearn.metrics import plot_roc_curve
    from sklearn.metrics import plot_confusion_matrix
    from sklearn.metrics import plot_classification_report

    X = data.drop(['State'],axis=1)
    y = data['State']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
    regressor = LinearRegression()
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    print('Mean Absolute Error:', mean_absolute_error(y_test, y_pred))
    print('Mean Squared Error:', mean_squared_error(y_test, y_pred))
    print('Root Mean Squared Error:', np.sqrt(mean_squared_error(y_test, y_pred)))
    print('Explained Variance Score:', explained_variance_score(y_test, y_pred))
    print('R2 Score:', r2_score(y_test, y_pred))
    print('Median Absolute Error:', median_absolute_error(y_test, y_pred))
    print('Mean Squared Log Error:', mean_squared_log_error(y_test, y_pred))
    print('Mean Absolute Percentage Error:', mean_absolute_percentage_error(y_test, y_pred))
    print('Max Error:', max_error(y_test, y_pred))
    print('Accuracy Score:', accuracy_score(y_test, y_pred))
    print('Precision Score:', precision_score(y_test, y_pred))
    print('Recall Score:', recall_score(y_test, y_pred))
    print('F1 Score:', f1_score(y_test, y_pred))
    print('ROC AUC Score:', roc_auc_score(y_test, y_pred))
    print('Confusion Matrix:', confusion_matrix(y_test, y_pred))
    print('Classification Report:', classification_report(y_test, y_pred))
    print('Precision Recall Curve:', precision_recall_curve(y_test, y_pred))
    print('AUC:', auc(y_test, y_pred))
    print('Precision Recall F1 Score:', precision_recall_fscore_support(y_test, y_pred))
    print('Plot Precision Recall Curve:', plot_precision_recall_curve(y_test, y_pred))
    print('Plot ROC Curve:', plot_roc_curve(y_test, y_pred))
    print('Plot Confusion Matrix:', plot_confusion_matrix(y_test, y_pred))
    print('Plot Classification Report:', plot_classification_report(y_test, y_pred))
    return regressor


def multiple_regression(data):
    from sklearn.linear_model import LinearRegression
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_squared_error
    from sklearn.metrics import r2_score
    from sklearn.metrics import mean_absolute_error
    from sklearn.metrics import explained_variance_score
    from sklearn.metrics import median_absolute_error
    from sklearn.metrics import mean_squared_log_error
    from sklearn.metrics import mean_absolute_percentage_error
    from sklearn.metrics import max_error
    from sklearn.metrics import accuracy_score
    from sklearn.metrics import precision_score
    from sklearn.metrics import recall_score
    from sklearn.metrics import f1_score
    from sklearn.metrics import roc_auc_score
    from sklearn.metrics import roc_curve
    from sklearn.metrics import confusion_matrix
    from sklearn.metrics import classification_report
    from sklearn.metrics import precision_recall_curve
    from sklearn.metrics import auc
    from sklearn.metrics import precision_recall_fscore_support
    from sklearn.metrics import plot_precision_recall_curve
    from sklearn.metrics import plot_roc_curve
    from sklearn.metrics import plot_confusion_matrix
    from sklearn.metrics import plot_classification_report

    X = data.drop(['State'],axis=1)
    y = data['State']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
    regressor = LinearRegression()
    regressor.fit(X_train, y_train)
    y_pred = regressor.predict(X_test)
    print('Mean Absolute Error:', mean_absolute_error(y_test, y_pred))
    print('Mean Squared Error:', mean_squared_error(y_test, y_pred))
    print('Root Mean Squared Error:', np.sqrt(mean_squared_error(y_test, y_pred)))  # Root Mean Squared Error
    print('Explained Variance Score:', explained_variance_score(y_test, y_pred))
    print('R2 Score:', r2_score(y_test, y_pred))
    print('Median Absolute Error:', median_absolute_error(y_test, y_pred))
    print('Mean Squared Log Error:', mean_squared_log_error(y_test, y_pred))
    print('Mean Absolute Percentage Error:', mean_absolute_percentage_error(y_test, y_pred))
    print('Max Error:', max_error(y_test, y_pred))
    print('Accuracy Score:', accuracy_score(y_test, y_pred))
    print('Precision Score:', precision_score(y_test, y_pred))
    print('Recall Score:', recall_score(y_test, y_pred))
    print('F1 Score:', f1_score(y_test, y_pred))
    print('ROC AUC Score:', roc_auc_score(y_test, y_pred))
    print('Confusion Matrix:', confusion_matrix(y_test, y_pred))
    print('Classification Report:', classification_report(y_test, y_pred))
    print('Precision Recall Curve:', precision_recall_curve(y_test, y_pred))
    print('AUC:', auc(y_test, y_pred))
    print('Precision Recall F1 Score:', precision_recall_fscore_support(y_test, y_pred))
    print('Plot Precision Recall Curve:', plot_precision_recall_curve(y_test, y_pred))
    print('Plot ROC Curve:', plot_roc_curve(y_test, y_pred))
    print('Plot Confusion Matrix:', plot_confusion_matrix(y_test, y_pred))
    print('Plot Classification Report:', plot_classification_report(y_test, y_pred))
    return regressor

#	Z-score, mean, mode, variance.
def z_score(data):
    return (data - data.mean()) / data.std()

def mean(data):
    return data.mean()

def mode(data):
    return data.mode()
    